# 📊 Meta Ads Pro

Dashboard profissional para gerenciamento e análise de campanhas do Meta Ads (Facebook/Instagram).

## ✨ Funcionalidades

- 🏠 **Visão Geral** — KPIs, gráficos de evolução, funil de performance
- 🎯 **Campanhas** — tabela completa, filtros, pausar/ativar
- 📦 **Conjuntos de Anúncios** — métricas detalhadas e frequência
- 🖼️ **Anúncios** — performance por criativo
- 📈 **Performance** — score de qualidade, gráficos comparativos
- 👥 **Público** — análise de alcance, frequência e saturação
- 💰 **Orçamento** — controle de gastos e limites
- 🤖 **Análise com IA** — insights automáticos + assistente de chat
- 🔔 **Alertas** — monitoramento automático de saúde das campanhas

## 🚀 Deploy na Vercel

### Opção 1 — Via GitHub (recomendado)

1. Faça upload desta pasta para um repositório no GitHub
2. Acesse [vercel.com](https://vercel.com) → **Add New Project**
3. Importe o repositório do GitHub
4. Clique em **Deploy** — pronto!

### Opção 2 — Via Vercel CLI

```bash
npm i -g vercel
cd meta-ads-pro
vercel --prod
```

### Opção 3 — Drag & Drop

1. Acesse [vercel.com/new](https://vercel.com/new)
2. Arraste a pasta `meta-ads-pro` diretamente na página

## 🔐 Como usar

1. Acesse a URL gerada pela Vercel
2. Insira seu **Access Token** do Meta ([Graph Explorer](https://developers.facebook.com/tools/explorer/))
3. Insira o **ID da conta de anúncios**
4. Clique em **Conectar**

### Permissões necessárias no token:
- `ads_read`
- `ads_management`

## 🔒 Segurança

O token é usado **apenas no seu navegador** para chamadas diretas à API do Meta. Nenhum dado é enviado a servidores externos.

---
Desenvolvido com ❤️ usando Meta Graph API v19.0 + Claude AI
